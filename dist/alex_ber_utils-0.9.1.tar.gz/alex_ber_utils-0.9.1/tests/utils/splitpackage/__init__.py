import os as _os
__path__.append(_os.path.join(_os.path.dirname(_os.path.dirname(__file__)), 'splitpackage_cont'))

