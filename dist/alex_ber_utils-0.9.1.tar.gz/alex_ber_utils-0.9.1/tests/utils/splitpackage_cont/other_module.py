

def theansweris():
    return 42